<div <?php echo e($attributes->merge(['class'=>'border rounded-lg'])); ?>>
    <div class="px-4 py-2 bg-gray-50 border-b rounded-t-lg font-medium text-gray-800"><?php echo e($title); ?></div>
    <div class="p-4 space-y-3">
        <?php echo e($slot); ?>

    </div>
</div>

<?php /**PATH C:\Users\Bao Uyen\Desktop\project\sone\resources\views/components/rate-card.blade.php ENDPATH**/ ?>