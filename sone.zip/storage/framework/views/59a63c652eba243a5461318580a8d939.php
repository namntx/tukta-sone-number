<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-xl font-semibold">Giá khách: <?php echo e($customer->name); ?></h1>
    <a href="<?php echo e(route('user.customers.show',$customer)); ?>" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
      Quay lại
    </a>
  </div>

  <form method="POST" action="<?php echo e(route('user.customers.rates.update',$customer)); ?>">
    <?php echo csrf_field(); ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="bg-white shadow rounded-lg p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4"><?php echo e($label); ?></h2>

        <div class="space-y-6">
          
          <?php if($key==='bac'): ?>
          <?php if (isset($component)) { $__componentOriginal53922df9027b667fa338ce5cdc03b04c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53922df9027b667fa338ce5cdc03b04c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-card','data' => ['title' => 'Giá đề']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Giá đề']); ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'de_dau','region' => $key,'text' => 'Đề đầu','data' => $data[$key]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'de_dau','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Đề đầu','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'de_duoi','region' => $key,'text' => 'Đề đuôi (Đề GĐB)','data' => $data[$key]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'de_duoi','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Đề đuôi (Đề GĐB)','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'de_duoi_4','region' => $key,'text' => 'Đề đuôi 4 số','data' => $data[$key],'digits' => 4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'de_duoi_4','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Đề đuôi 4 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $attributes = $__attributesOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $component = $__componentOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__componentOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
          <?php endif; ?>

          
          <?php if (isset($component)) { $__componentOriginal53922df9027b667fa338ce5cdc03b04c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53922df9027b667fa338ce5cdc03b04c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-card','data' => ['title' => 'Giá bao lô']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Giá bao lô']); ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'bao_lo','region' => $key,'text' => 'Bao lô 2 số','data' => $data[$key],'digits' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'bao_lo','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Bao lô 2 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'bao_lo','region' => $key,'text' => 'Bao lô 3 số','data' => $data[$key],'digits' => 3]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'bao_lo','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Bao lô 3 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 3]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'bao_lo','region' => $key,'text' => 'Bao lô 4 số','data' => $data[$key],'digits' => 4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'bao_lo','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Bao lô 4 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $attributes = $__attributesOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $component = $__componentOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__componentOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>

          
          <?php if (isset($component)) { $__componentOriginal53922df9027b667fa338ce5cdc03b04c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53922df9027b667fa338ce5cdc03b04c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-card','data' => ['title' => 'Giá xiên đá']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Giá xiên đá']); ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'da_thang','region' => $key,'text' => 'Đá thẳng (1 đài)','data' => $data[$key],'dai' => 1]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'da_thang','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Đá thẳng (1 đài)','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'dai' => 1]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'da_xien','region' => $key,'text' => 'Đá chéo (đá 2 đài)','data' => $data[$key],'dai' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'da_xien','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Đá chéo (đá 2 đài)','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'dai' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'xien','region' => $key,'text' => 'Xiên 2','data' => $data[$key],'xien' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'xien','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Xiên 2','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'xien' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'xien','region' => $key,'text' => 'Xiên 3','data' => $data[$key],'xien' => 3]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'xien','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Xiên 3','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'xien' => 3]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'xien','region' => $key,'text' => 'Xiên 4','data' => $data[$key],'xien' => 4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'xien','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Xiên 4','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'xien' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $attributes = $__attributesOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $component = $__componentOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__componentOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>

          
          <?php if (isset($component)) { $__componentOriginal53922df9027b667fa338ce5cdc03b04c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53922df9027b667fa338ce5cdc03b04c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-card','data' => ['title' => 'Giá Xỉu chủ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Giá Xỉu chủ']); ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'xiu_chu','region' => $key,'text' => 'Xỉu chủ','data' => $data[$key]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'xiu_chu','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => 'Xỉu chủ','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $attributes = $__attributesOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $component = $__componentOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__componentOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>

          
          <?php if(in_array($key,['trung','nam'])): ?>
          <?php if (isset($component)) { $__componentOriginal53922df9027b667fa338ce5cdc03b04c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53922df9027b667fa338ce5cdc03b04c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-card','data' => ['title' => 'Giá Bảy lô (7 giải cuối)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Giá Bảy lô (7 giải cuối)']); ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'bay_lo','region' => $key,'text' => '2 số','data' => $data[$key],'digits' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'bay_lo','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => '2 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal11709ec5895d948432a91161619d50a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11709ec5895d948432a91161619d50a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rate-row','data' => ['code' => 'bay_lo','region' => $key,'text' => '3 số','data' => $data[$key],'digits' => 3]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rate-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => 'bay_lo','region' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'text' => '3 số','data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data[$key]),'digits' => 3]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $attributes = $__attributesOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__attributesOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11709ec5895d948432a91161619d50a7)): ?>
<?php $component = $__componentOriginal11709ec5895d948432a91161619d50a7; ?>
<?php unset($__componentOriginal11709ec5895d948432a91161619d50a7); ?>
<?php endif; ?>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $attributes = $__attributesOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__attributesOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53922df9027b667fa338ce5cdc03b04c)): ?>
<?php $component = $__componentOriginal53922df9027b667fa338ce5cdc03b04c; ?>
<?php unset($__componentOriginal53922df9027b667fa338ce5cdc03b04c); ?>
<?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6 flex justify-end">
      <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
        Lưu thay đổi
      </button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bao Uyen\Desktop\project\sone\resources\views/user/customers/rates-edit.blade.php ENDPATH**/ ?>